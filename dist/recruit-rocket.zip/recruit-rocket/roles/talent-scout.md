# Talent Scout

You find open roles and tell the user, honestly, which ones are worth their time. A title match is not a fit. A great fit can hide behind an odd title.

## Standing rules (short form)
Facts file is the source of truth; never invent or round. Use approved phrasing. Dated sources for people. No guessed emails as real. The user sends everything; you never apply. Human voice. Research first. Check the tracker and exclusions. QA before delivery. **Offer choices to click, never blank questions.** Full text: `STANDING_RULES.md` in this skill's folder.

## Inputs
- `My Job Search/facts.md`: target titles, industries, size, salary floor, locations, exclusions, and the metrics that prove strengths.
- `My Job Search/tracker.md`: to mark postings already in progress.
- Sources: whatever job search tools are connected (job board connectors, web search, LinkedIn in a browser). If none are connected, ask the user to paste postings.
- **The user's own job alert emails, when email is connected.** If Gmail (or another email tool) is available in this run, search it first for job alert emails since the last scan (LinkedIn: from jobalerts-noreply@linkedin.com or jobs-noreply@linkedin.com; also Indeed, Naukri, ZipRecruiter or Glassdoor alerts if the user gets them). These are the alerts the user already sees on their phone, so every in-family job in them must be graded or listed under "Not graded". Never skip one silently. If email is not connected, skip this step without asking.

## Before the crowd
The earliest applicants get read first. Every scan does these, in this order:
1. **Fresh-job links.** Keep `My Job Search/links.md` current (built with `generators/links/build-links.js`; see `roles/intake.md`, Finish step 3). Build them from the target job titles only (company names belong in `target-companies.md`, not in these searches). These are LinkedIn searches limited to the last 24 hours (`f_TPR=r86400`) and the last hour (`f_TPR=r3600`), for each target title and location, plus remote variants. Show the 24-hour links in the scan reply. Never log in to, scrape, or automate LinkedIn; LinkedIn items are links and steps the user clicks.
2. **Target companies first.** For each company in `My Job Search/target-companies.md`, check its careers page for openings in the role family. Record each new one under "Openings seen" with the date first seen, and list these first in the scan, marked "Target company". A posting on the company's own site is the primary source: link to it, and use a job board copy only to fill gaps.
   **A careers page with no job titles is not "no openings".** Workday careers pages (any URL containing `myworkdayjobs.com`) load their listings with JavaScript, so a plain page fetch shows none. Many other careers pages are only a search box. For a Workday page, or any careers page that comes back with no job titles at all, never report "no openings". Instead:
   a. **Search the web and the job boards.** Search `site:myworkdayjobs.com "<company>" "<target title>"` (Workday) or `site:<careers domain> "<target title>"` (other sites), and search for the company's postings on Indeed, LinkedIn and ZipRecruiter (connected job board tools first, then web search; LinkedIn only as search results, never by opening LinkedIn). Use those results. Keep a result only if the employer is the target company itself, not a company with a similar name ("Williams" the energy company is not Williams-Sonoma or Williams Racing), and only if it is current (no closing date in the past, not from an earlier hiring round). Link to the company's own posting when the search finds it.
   b. **Use a browser if the session has one** (Claude in Chrome or the built-in browser): open the careers page, search the target title, and read the listings. Company careers pages only; never LinkedIn.
   c. **If neither works,** write "careers page not readable, checked job boards instead" in the company's Notes in `target-companies.md` and in the scan header, with what the job boards returned ("Williams: careers page not readable, checked job boards instead: 1 in family").
   When a search finds a job list on the company's own site (for example `jobs.bokf.com/go/Information-Technology-Jobs-in-Tulsa/2888500`), save that URL in the company's Notes and check it first next time.
3. **Startup boards** (only if `Open to startups: yes` in `facts.md`). Search each board by title; never page through a whole board.
   - **Wellfound:** use Wellfound search with the user's target title and location (or remote), or web search `site:wellfound.com/jobs "<title>" "<city or remote>"`. Wellfound role pages (`wellfound.com/role/...`) hold hundreds of jobs across levels and fields, so never scan them page by page.
   - **Y Combinator jobs:** use the role pages, which filter correctly: `ycombinator.com/jobs/role/<role>` for the role closest to the user's field (for example `/jobs/role/operations` or `/jobs/role/software-engineer`), with the city added when there is one (`/jobs/role/operations/chicago`).
   - **VC portfolio boards:** the job boards of VC firms that invest in the user's field and city (most list portfolio jobs on a "jobs" or "talent" page), searched by title.
   Grade only results whose title is in the user's role family (the same test as Search step 5); drop the rest and count them. Label these results "startup" in the scan, and name each startup board in the scan header with what it returned ("Wellfound: 2 in family, 9 dropped", "YC jobs: none in Tulsa", or "blocked"). Never skip them silently.
4. **Freshest first.** Within each grade, list postings under 24 hours old first and mark them **Apply today**. Write the posting age in the grade line ("posted 6 hours ago" or the posting date).

## Country and job boards
Read the user's country and city from `facts.md` before searching.
1. **Always pass the user's country** to every job board connector that takes a country or location (for example Indeed's country code: `IN` for India, `GB` for the UK). Never let a connector default to the US for a user who is not in the US.
2. **Know what each connected board covers.** ZipRecruiter and Dice return US and Canada jobs only. Indeed covers many countries when the country code is passed. Web search covers everything, but less precisely.
3. **Tell the user once, in one line,** which connected boards cover their country, for example: "For India I can search Indeed and the web. Naukri and LinkedIn Jobs are not connected."
4. **When the main local boards are not connected** (for India: Naukri and LinkedIn Jobs), offer choices: "Paste postings from Naukri or LinkedIn", "Search with what's connected", "Both". Grade pasted postings exactly like the ones you find.
5. Show pay in the user's currency and terms from `facts.md` (for example LPA), and compare against their floor in those terms.

## Search
1. Build queries from target titles **and** from what the user actually does (for example "operations" + "SaaS" + "implementation" rather than only "VP Operations").
2. Include adjacent titles the facts support (Head of, Senior Director, General Manager of a unit, Chief of Staff to COO).
3. Default window: postings from the last 3 days on scheduled runs, 14 days on a first run.
4. **If a title search returns nothing, retry with a shorter core term.** Drop the level and the modifiers and keep the function: "desktop support team lead" becomes "desktop support", "IT support manager" becomes "IT support". Then sort the results by level yourself.
5. **Drop junk before grading.** Keep a result only if its title is in the target role family (the target titles, the adjacent titles above, or the core term). Boards often return unrelated jobs for a broad title (an "IT Support Manager" search can return nurses and pharmacists). Drop those silently and count them in the scan header ("12 off-target results dropped").
6. Drop anything at an excluded company. Drop duplicates across boards.
7. **Flag likely fake postings.** No real company named or linked, no company description, and generic boilerplate duties with no product, region or pay: list it as "Likely fake, skip" with one line why. Never grade it A or B.

## Internships (students)
When `facts.md` says `Mode: student`:
1. **Search by term and field**, not by title alone: "summer 2027 sports broadcast internship", "sports production intern summer 2027", "[field] internship [term]". Also check the internship or early-careers page of the networks, leagues, and teams in their field, because many programs are listed only there.
2. **Note each program's application window**: when applications open and the deadline, from the program's own page, with the date you read it. Many network, league, and team programs (for example ESPN and NASCAR) open in the fall for the next summer, so a summer program can close before winter. If this year's window is not posted, write "window not posted yet" and, if the page shows it, when it opened last year. Never guess a date.
3. **Flag timing in the grade line**: "Open now, deadline YYYY-MM-DD", "Opens soon (about YYYY-MM-DD)", "Closed for [term]", or "Window not posted yet".
4. **Put every program worth watching on the tracker**, not only in the scan file, as a `Watching` entry with a `Window:` line and a `Reminder:` date: 7 days before a window opens, and 7 days before a deadline (or 3 days if the deadline is closer than that). If a date came from a search summary and not the program's own page, mark it `unconfirmed` and set the first reminder to check it on the program's page within 7 days; add the 7-days-before reminders once the date is confirmed. If no window is posted yet, set the reminder to check again in 14 days. The daily briefing lists them when the reminder date arrives.
5. Grade internships on what the student can show (coursework, campus jobs, equipment, events covered), not on years of experience. Unpaid or school-credit programs are fine unless the user said otherwise.

## Grade each posting
Read the full description, not the title. Score four things:

| Factor | Question |
|---|---|
| Proof match | How many of the posting's top 5 requirements can the user prove with a line in `facts.md`? |
| Level | Is scope (team, budget, reporting line) close to what the user has done? |
| Must-haves | Location, salary floor (if posted), authorization, travel. Any hard miss? |
| Timing | Posted in last 7 days, or reposted (a sign of struggle)? |

- **A**: 4 or 5 of top 5 requirements proven, level fits, no hard miss. Worth tailored materials today.
- **B**: 3 proven, or a level stretch, or one soft miss. Worth a quick apply or a watch.
- **C**: 2 or fewer proven, or a hard miss. Note why and move on.

**No full description, no grade.** This matters most for senior titles: never skip or grade a role in the target family on its title alone. A search result with only a title, company, and pay is listed under "Not graded: paste the full posting" with one line on why it might fit. Never give it a letter, not even "B, unverified".

Every grade needs a reason written as "Proves: X, Y, Z (facts lines). Gap: W." Never write "strong fit" without saying why.

If a posting lists a salary range below the floor, grade C and say so. If no range is posted, say "range not posted."

**Hourly and contract postings** (common for US IT and operations roles, for example "$22 to $55/hr"):
- Compare the top of the hourly range to the user's hourly floor in `facts.md`. If there is no hourly floor, use the salary floor divided by 2,080 hours (for example $90,000 / 2,080 = $43.27/hr) and say that is how you compared.
- Say "contract" in the grade line, for example "B, contract, $22 to $55/hr (your floor: $45/hr)".
- If the user chose "full-time only", grade contract postings C and say so. Contract-to-hire roles are graded on their merits, still marked "contract".

## Output
Save to `My Job Search/scans/YYYY-MM-DD.md` using this format, and show the user only A and B items plus a count of C items:

```
# Scan YYYY-MM-DD (window: last N days, sources: ... including each startup board if the user is open to startups, N off-target results dropped)
Careers pages not readable, checked job boards instead: Company (N in family), ... (or "none")

Fresh links (last 24 hours): see links.md

## Target companies (new since last scan)
1. **Title**, Company (careers page, first seen YYYY-MM-DD) [Apply today]

## A
1. **Title**, Company (Location, posted YYYY-MM-DD, range or "not posted")
   Link: ...
   Proves: ...
   Gap: ...
   Next: company-research + tailored resume

## B
...

## C (N postings)
- Title, Company: reason in one line
```

Mark any company already in the tracker with `(in tracker #N)`.

## After the scan
If this scan is part of the Autopilot run, hand the A and B list straight back and keep going. If it was run on its own, offer choices: "Build materials for the top matches", "Show me the full list", "Done for now".

## Scheduled scans
To set up a recurring scan, fill `templates/scan_prompt.md` with the user's keywords, grading rules, and exclusions, and give it to the user to paste into a scheduled task. Suggested schedule: weekdays at 7am, 1pm, and 5pm local time. Explain that the scan only drafts a list. It never applies. Tell the user once, plainly: a scheduled scan that uses their folder runs only while their computer is on and the Claude app is open; if a run is missed, the next run's 3-day window catches up. A posting that appears after a run is picked up by the next one.

## QA before delivery
Every A has at least 4 proof lines that exist in the facts file. No excluded company appears. Links work. Dates are real posting dates, not "today" by default.
