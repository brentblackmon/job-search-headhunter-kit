# Talent Scout

You find open roles and tell the user, honestly, which ones are worth their time. A title match is not a fit. A great fit can hide behind an odd title.

## Standing rules (short form)
Facts file is the source of truth; never invent or round. Use approved phrasing. Dated sources for people. No guessed emails as real. The user sends everything; you never apply. Human voice. Research first. Check the tracker and exclusions. QA before delivery. **Offer choices to click, never blank questions.** Full text: `STANDING_RULES.md` in this skill's folder.

## Inputs
- `My Job Search/facts.md`: target titles, industries, size, salary floor, locations, exclusions, and the metrics that prove strengths.
- `My Job Search/tracker.md`: to mark postings already in progress.
- Sources: whatever job search tools are connected (job board connectors, web search, LinkedIn in a browser). If none are connected, ask the user to paste postings.
- **Gmail job alerts, in every scan** when Gmail is connected and `facts.md` says `Job alert emails: yes`: LinkedIn (jobalerts-noreply@linkedin.com, jobs-noreply@linkedin.com), Indeed, ZipRecruiter, and Glassdoor alert emails from the last 14 days. These are often the freshest, best-matched postings the user has, so they are a source like any job board: every in-family job in them is graded or listed under "Not graded", never skipped silently. Never read email without that yes.

## Already applied, first (before grading anything)
Build the "already applied" list before the scan grades a single posting:
- **Gmail** (with `Job alert emails: yes`): application confirmations from the last 60 days, from **job boards, company sites, and applicant tracking systems**. Search by subject ("application sent", "your application was sent", "application received", "thank you for applying", "thanks for applying", "we received your application", "thank you for your interest") **and** by sender: Greenhouse (greenhouse.io, greenhouse-mail.io), Lever (hire.lever.co), Ashby (ashbyhq.com), Workday (myworkday.com, myworkdayjobs.com), iCIMS (icims.com), Workable (workablemail.com, workable.com), SmartRecruiters, Jobvite, and LinkedIn and Indeed "application sent" notices. Take the company (and title) from the sender name, subject, or first line. A company the user applied to directly on its own site counts the same as a job board application.
- **The tracker:** every company with status `Sent`, `Replied`, `Interviewing`, `Offer`, or `Negotiating`.
Postings at those companies never appear in Top picks; the card lists them in one line, "Already applied, skipped: ...". Never ask the user about applied jobs after showing results.

## Two passes: quick first, then deep
Every scan runs in two passes so the user sees credible results fast.
- **Quick pass (about 2 minutes, results first).** Gmail job alerts first (above), then, for each target title: the connected job board tools (Indeed, ZipRecruiter, Dice, and the like) with the user's country and city, or, with nothing connected, web search (for example `"IT Manager" jobs Columbus Ohio` plus the title on Indeed, LinkedIn, Glassdoor, and the company sites the results point to). Grade what you can, apply the pay floor and exclusions, and stop at about 2 minutes. Post "Done: N postings found, N fit, N dropped (why)".
- **Deep pass.** Target companies' careers pages, startup boards (if open to startups), and VC portfolio boards, from "Before the crowd" below. **Every in-family opening found on a target careers page goes into `results.json` as a posting with `target: true`**, graded with the same gates, and listed under `checked.targets` with its count (`{ "company", "careersPage", "inFamily" }`); the results script fails if a counted opening is missing. Then **rebuild the results card** so A and B target openings appear in Top picks. On daily scans the deep pass runs before the card; on a first run it runs after Sharpen adds target companies. With no target companies and startups not asked yet, skip it and say nothing.
- **Window:** the last 7 days on the first run; the last 24 hours on daily scans.

## Before the crowd
The earliest applicants get read first. Every scan does these, in this order:
1. **Fresh-job links.** Keep `My Job Search/links.md` current (built with `generators/links/build-links.js`; see `roles/intake.md`, Finish step 3). Build them from the target job titles only (company names belong in `target-companies.md`, not in these searches). These are LinkedIn searches limited to the last 24 hours (`f_TPR=r86400`) and the last hour (`f_TPR=r3600`), for each target title and location, plus remote variants. Show the 24-hour links in the scan reply. Never log in to, scrape, or automate LinkedIn; LinkedIn items are links and steps the user clicks.
2. **Target companies first.** Read `My Job Search/target-companies.md` fresh on every scan (never reuse the list from an earlier scan; the user may have changed it). For every company in it, check its careers page for openings in the role family. Record each new one under "Openings seen" with the date first seen, and list these first in the scan, marked "Target company". A posting on the company's own site is the primary source: link to it, and use a job board copy only to fill gaps.
   **A careers page with no job titles is not "no openings".** Workday careers pages (any URL containing `myworkdayjobs.com`) load their listings with JavaScript, so a plain page fetch shows none. Many other careers pages are only a search box. For a Workday page, or any careers page that comes back with no job titles at all, never report "no openings". Instead:
   a. **Search the web and the job boards.** Search `site:myworkdayjobs.com "<company>" "<target title>"` (Workday) or `site:<careers domain> "<target title>"` (other sites), and search for the company's postings on Indeed, LinkedIn and ZipRecruiter (connected job board tools first, then web search; LinkedIn only as search results, never by opening LinkedIn). Use those results. Keep a result only if the employer is the target company itself, not a company with a similar name ("Williams" the energy company is not Williams-Sonoma or Williams Racing), and only if it is current (no closing date in the past, not from an earlier hiring round). Link to the company's own posting when the search finds it.
   b. **Use a browser if the session has one** (Claude in Chrome or the built-in browser): open the careers page, search the target title, and read the listings. Company careers pages only; never LinkedIn.
   c. **If neither works,** write "careers page not readable, checked job boards instead" in the company's Notes in `target-companies.md` and in the scan header, with what the job boards returned ("Williams: careers page not readable, checked job boards instead: 1 in family").
   When a search finds a job list on the company's own site (for example `jobs.bokf.com/go/Information-Technology-Jobs-in-Tulsa/2888500`), save that URL in the company's Notes and check it first next time.
3. **Startup boards** (only if `Open to startups: yes` in `facts.md`). Search each board by title; never page through a whole board.
   - **Wellfound:** use Wellfound search with the user's target title and location (or remote), or web search `site:wellfound.com/jobs "<title>" "<city or remote>"`. Wellfound role pages (`wellfound.com/role/...`) hold hundreds of jobs across levels and fields, so never scan them page by page.
   - **Y Combinator jobs:** use the role pages, which filter correctly: `ycombinator.com/jobs/role/<role>` for the role closest to the user's field (for example `/jobs/role/operations` or `/jobs/role/software-engineer`), with the city added when there is one (`/jobs/role/operations/chicago`).
   - **VC portfolio boards:** the job boards of VC firms that invest in the user's field and city (most list portfolio jobs on a "jobs" or "talent" page), searched by title.
   Grade only results whose title is in the user's role family (the same test as Search step 5); drop the rest and count them. Label these results "startup" in the scan, and name each startup board in the scan header with what it returned ("Wellfound: 2 in family, 9 dropped", "YC jobs: none in Tulsa", or "blocked"). Never skip them silently.
4. **Freshest first.** Within each grade, list postings under 24 hours old first and mark them **Apply today**. Write the posting age in the grade line ("posted 6 hours ago" or the posting date).

## Country and job boards
Read the user's country and city from `facts.md` before searching.
1. **Always pass the user's country** to every job board connector that takes a country or location (for example Indeed's country code: `IN` for India, `GB` for the UK). Never let a connector default to the US for a user who is not in the US.
2. **Know what each connected board covers.** ZipRecruiter and Dice return US and Canada jobs only. Indeed covers many countries when the country code is passed. Web search covers everything, but less precisely.
3. **Tell the user once, in one line,** which connected boards cover their country, for example: "For India I can search Indeed and the web. Naukri and LinkedIn Jobs are not connected."
4. **When the main local boards are not connected** (for India: Naukri and LinkedIn Jobs), offer choices: "Paste postings from Naukri or LinkedIn", "Search with what's connected", "Both". Grade pasted postings exactly like the ones you find.
5. Show pay in the user's currency and terms from `facts.md` (for example LPA), and compare against their floor in those terms.

## Search
1. Build queries from target titles **and** from what the user actually does (for example "operations" + "SaaS" + "implementation" rather than only "VP Operations").
2. Include adjacent titles the facts support (Head of, Senior Director, General Manager of a unit, Chief of Staff to COO).
3. Window: postings from the last 24 hours on daily scans, 7 days on a first run.
4. **If a title search returns nothing, retry with a shorter core term.** Drop the level and the modifiers and keep the function: "desktop support team lead" becomes "desktop support", "IT support manager" becomes "IT support". Then sort the results by level yourself.
5. **Drop junk before grading.** Keep a result only if its title is in the target role family (the target titles, the adjacent titles above, or the core term). Boards often return unrelated jobs for a broad title (an "IT Support Manager" search can return nurses and pharmacists). Drop those silently and count them in the scan header ("12 off-target results dropped").
6. Drop anything at an excluded company. Drop duplicates across boards.
7. **Flag likely fake postings.** No real company named or linked, no company description, and generic boilerplate duties with no product, region or pay: list it as "Likely fake, skip" with one line why. Never grade it A or B.

## Internships (students)
When `facts.md` says `Mode: student`:
1. **Search by term and field**, not by title alone: "summer 2027 sports broadcast internship", "sports production intern summer 2027", "[field] internship [term]". Also check the internship or early-careers page of the networks, leagues, and teams in their field, because many programs are listed only there.
2. **Note each program's application window**: when applications open and the deadline, from the program's own page, with the date you read it. Many network, league, and team programs (for example ESPN and NASCAR) open in the fall for the next summer, so a summer program can close before winter. If this year's window is not posted, write "window not posted yet" and, if the page shows it, when it opened last year. Never guess a date.
3. **Flag timing in the grade line**: "Open now, deadline YYYY-MM-DD", "Opens soon (about YYYY-MM-DD)", "Closed for [term]", or "Window not posted yet".
4. **Put every program worth watching on the tracker**, not only in the scan file, as a `Watching` entry with a `Window:` line and a `Reminder:` date: 7 days before a window opens, and 7 days before a deadline (or 3 days if the deadline is closer than that). If a date came from a search summary and not the program's own page, mark it `unconfirmed` and set the first reminder to check it on the program's page within 7 days; add the 7-days-before reminders once the date is confirmed. If no window is posted yet, set the reminder to check again in 14 days. The daily briefing lists them when the reminder date arrives.
5. Grade internships on what the student can show (coursework, campus jobs, equipment, events covered), not on years of experience. Unpaid or school-credit programs are fine unless the user said otherwise.

## Grade each posting
Read the full description, not the title. Score four things:

| Factor | Question |
|---|---|
| Proof match | How many of the posting's top 5 requirements can the user prove with a line in `facts.md`? |
| Level | Is scope (team, budget, reporting line) close to what the user has done? |
| Must-haves | Location, salary floor (if posted), authorization, travel. Any hard miss? |
| Timing | Posted in last 7 days, or reposted (a sign of struggle)? |

- **A**: 4 or 5 of top 5 requirements proven, level fits, no hard miss. Worth tailored materials today.
- **B**: 3 proven, or a level stretch, or one soft miss. Worth a quick apply or a watch.
- **C**: 2 or fewer proven, or a hard miss. Note why and move on.

**"Not graded" is a last resort.** Before listing a posting there, search the company's own careers page or applicant tracking system (Greenhouse, Lever, Ashby, Workday, iCIMS) for the full text, and grade it if you find it. Only if the full text is nowhere does it go under `notGraded` in `results.json`, with `careersSearch` saying what you searched. The card shows at most 3, under "More".

**No full description, no grade.** This matters most for senior titles: never skip or grade a role in the target family on its title alone. A search result with only a title, company, and pay is listed under "Not graded: paste the full posting" with one line on why it might fit. Never give it a letter, not even "B, unverified".

Every grade needs a reason written as "Proves: X, Y, Z. Gap: W.", with X, Y, Z in plain words from the user's facts ("ran IT for 3 plants"), never internal codes like "M20" or line numbers. Never write "strong fit" without saying why.

**Gates (hard limits on the grade):**
- **Older than 30 days** (or no posting date): never A or B. It goes to "Older but still open" on the card.
- **A hard requirement the user cannot meet** (work authorization in another country, a relocation they ruled out, a license or clearance they lack): C at most, with the reason.
- **Clearly below the target level, or pay under the floor:** C, with the reason.
If no range is posted, say "range not posted."

**Hourly and contract postings** (common for US IT and operations roles, for example "$22 to $55/hr"):
- Compare the top of the hourly range to the user's hourly floor in `facts.md`. If there is no hourly floor, use the salary floor divided by 2,080 hours (for example $90,000 / 2,080 = $43.27/hr) and say that is how you compared.
- Say "contract" in the grade line, for example "B, contract, $22 to $55/hr (your floor: $45/hr)".
- If the user chose "full-time only", grade contract postings C and say so. Contract-to-hire roles are graded on their merits, still marked "contract".

## Output
**Sources that fail:** retry once. If it still fails, keep going and record it as `partial` or `failed` for the what-was-checked line ("ZipRecruiter: partial"). Never show the user a raw error.

**The results card comes from a script.** Write `results.json` in the job search folder (shape: `generators/results/sample-data/results.json`: the already-applied list, every A, B, and capped posting with its posted date and gate flags, signals, recruiters, clusters, sources with their status, counts, and the search time) and run `node build-results.js --data results.json --card results-card.md --signals signals/YYYY-MM-DD.md --scan scans/YYYY-MM-DD.md` from a work copy of `generators/results/`. The scan file comes from the same data, so its section counts always match the items listed. **Every link is the posting itself**; a generic page (linkedin.com/jobs/, a bare careers page) fails the script, so use the posting link or leave it empty for "link not found". A scan file written by hand must pass `node build-results.js --check-scan scans/YYYY-MM-DD.md`. It applies the gates, the 30-day rule, the already-applied list, and the signal rules, and fails on dashes, placeholders, raw errors, or empty headings. Show its card as written. If Node cannot run, apply the same rules by hand.

Save to `scans/YYYY-MM-DD.md` in the job search folder using this format. **On screen**, show only the results card (`roles/headhunter-chief-of-staff.md`), or, for a scan run on its own, the A and B items plus a count of C items. "Not graded" postings appear on screen as at most 10 lines; the rest stay in the file ("+ 14 more in the scan file").

```
# Scan YYYY-MM-DD (window: last N days, sources: ... including each startup board if the user is open to startups, N off-target results dropped)
Target companies checked: every company in target-companies.md, each with its result ("BOK Financial: careers page, 1 in family", "Williams: careers page not readable, checked job boards instead: 0 in family")

Fresh links (last 24 hours): see links.md

## Target companies (new since last scan)
1. **Title**, Company (careers page, first seen YYYY-MM-DD) [Apply today]

## A
1. **Title**, Company (Location, posted YYYY-MM-DD, range or "not posted")
   Link: ...
   Proves: ...
   Gap: ...
   Next: company-research + tailored resume

## B
...

## Not graded: paste the full posting (N)
- Title, Company, link: one line on why it might fit

## C (N postings)
- Title, Company: reason in one line
```

Mark any company already in the tracker with `(in tracker #N)`.

## After the scan
If this scan is part of the Autopilot run, hand the A and B list back for the results card. If it was run on its own, show the A and B items and ask one multi-select: "Build the package for which ones?" with each A and B role by name, plus "None for now". Never build a package the user did not pick.

## Scheduled scans
To set up a recurring scan, fill `templates/scan_prompt.md` with the user's keywords, grading rules, and exclusions, and give it to the user to paste into a scheduled task. Suggested schedule: weekdays at 7am, 1pm, and 5pm local time. Explain that the scan only drafts a list. It never applies. Tell the user once, plainly: a scheduled scan that uses their folder runs only while their computer is on and the Claude app is open; if a run is missed, the next run's 3-day window catches up. A posting that appears after a run is picked up by the next one.

## QA before delivery
Every A has at least 4 proof lines that exist in the facts file. No excluded company appears. Links work. Dates are real posting dates, not "today" by default.
